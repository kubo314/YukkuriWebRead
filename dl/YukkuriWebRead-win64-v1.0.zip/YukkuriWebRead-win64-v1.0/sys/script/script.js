//関数定義
function formatTime(seconds) {
    let hours = Math.floor(seconds / 3600);
    let minutes = Math.floor((seconds % 3600) / 60);
    let remainingSeconds = Math.floor(seconds % 60);

    let formattedTime = 
        (hours > 0 ? String(hours).padStart(2, "0") + ":" : "") +
        String(minutes).padStart(2, "0") +
        ":" +
        String(remainingSeconds).padStart(2, "0");
  
    return formattedTime;
}
//------------------------------

const selectElement = document.querySelector("#select");
const urlInputElement = document.querySelector("#urlInput");
const audioElement = document.querySelector("#voiceWav");

selectElement.value = Number(localStorage.getItem("voiceIndex"))
window.globalFunction.niceSelect([selectElement]);

urlInputElement.onfocus = function () {
    document.querySelector("#urlInputArea").style.borderColor = "#999";
};
urlInputElement.onblur = function() {
    document.querySelector("#urlInputArea").style.borderColor = "#e8e8e8";
};
document.querySelector("#deleteUrl").addEventListener("click", function() {
    urlInputElement.value = "";
    urlInputElement.focus();
});

function make_voice() {
    const Http = new XMLHttpRequest();
    const inputUrl = document.querySelector("#urlInput").value;
    const voiceIndex = selectElement.value;
    const url = `http://localhost:5000/?voice_index=${voiceIndex}&url=${inputUrl}`;
    const loadingElement = document.querySelector(".loader");

    if (inputUrl == "") {
        document.querySelector("#errMessage").textContent = "URLを入力してください。"
        return;
    }
    loadingElement.style.opacity = "1";
    Http.open("GET", url);
    Http.send();
    document.querySelector("#errMessage").textContent = ""
    Http.onreadystatechange = function() {
        if(this.readyState == 4 && this.status == 200){
            if (Http.responseText != "") {
                document.querySelector("#controller").style.opacity = "1";
                document.querySelector("#controller").style.pointerEvents = "auto";
                
                audioElement.src = JSON.parse(Http.responseText || "null")["datas"][0];
                document.querySelector("#title").textContent = JSON.parse(Http.responseText)["datas"][1];
                loadingElement.style.opacity = "0";
                audioElement.addEventListener('loadeddata', function() {
                    document.querySelector("#timeStampEnd").textContent = formatTime(audioElement.duration);

                    startAndStopElem.classList.remove("pause");
                    startAndStopElem.classList.add("start");
                    seekBarControlByAudio();
                    audioElement.playbackRate = Number(localStorage.getItem("speed")) * 3;
                });
                seekBarControlByAudio();
                document.querySelector("#errMessage").textContent = ""
            } else {
                loadingElement.style.opacity = "0";
                document.querySelector("#errMessage").textContent = "音声の生成に失敗しました。"
            }
        } else {
            loadingElement.style.opacity = "0";
            document.querySelector("#errMessage").textContent = "音声の生成に失敗しました。"
        }
    }
};
document.querySelector("#make").addEventListener("click", make_voice);
urlInputElement.addEventListener("keydown", function (e) {
    if (e.keyCode == 13) {
        make_voice();
    }
});
const negativeColorCode = "#737f8f";
const positiveColorCode = "#e3ebed";
const seekBarElement = document.querySelector(".seekBar");
seekBarElement.addEventListener("input", function(){
    let seekBarNegative = seekBarElement.value / seekBarElement.max;
    seekBarElement.style.background = `linear-gradient(90deg, ${negativeColorCode} 0%, ${negativeColorCode} ${seekBarNegative * 100}%, ${positiveColorCode} ${seekBarNegative * 100}%, ${positiveColorCode} 100%)`;

    audioElement.currentTime = audioElement.duration * seekBarNegative;
    document.querySelector("#timeStampStart").textContent = formatTime(audioElement.currentTime);
});
seekBarElement.onfocus = function () {
    seekBarElement.classList.add("focusSeekBar");
};
seekBarElement.onblur = function() {
    seekBarElement.classList.remove("focusSeekBar");
};

function seekBarControlByAudio() {
    if (isNaN(audioElement.duration)) {
        return;
    }
    let seekBarNegative = audioElement.currentTime / audioElement.duration;
    seekBarElement.style.background = `linear-gradient(90deg, ${negativeColorCode} 0%, ${negativeColorCode} ${seekBarNegative * 100}%, ${positiveColorCode} ${seekBarNegative * 100}%, ${positiveColorCode} 100%)`;

    seekBarElement.value = seekBarElement.max * seekBarNegative;

    document.querySelector("#timeStampStart").textContent = formatTime(audioElement.currentTime);
}
setInterval(function() {
    seekBarControlByAudio();
}, 1000);

const startAndStopElem = document.querySelector("#startAndStop");
function startAndStop() {
    startAndStopElem.classList.toggle("start");
    startAndStopElem.classList.toggle("pause");
    if (audioElement.paused) {
        audioElement.play();
    } else {
        audioElement.pause();
    }
    seekBarControlByAudio();
}
startAndStopElem.addEventListener("click", function(){
    startAndStop();
});
document.querySelector("#replay").addEventListener("click", function() {
    audioElement.currentTime -= 5;
    seekBarControlByAudio();
});
document.querySelector("#forward").addEventListener("click", function() {
    audioElement.currentTime += 5;
    seekBarControlByAudio();
});
window.addEventListener("keydown", function(event) {
    if (event.code == "ArrowLeft") {
        audioElement.currentTime -= 5;
        seekBarControlByAudio();
    }
    if (event.code == "ArrowRight") {
        audioElement.currentTime += 5;
        seekBarControlByAudio();
    }
    if (event.code == "KeyL") {
        audioElement.currentTime -= 5;
        seekBarControlByAudio();
    }
    if (event.code == "ArrowRight") {
        audioElement.currentTime += 5;
        seekBarControlByAudio();
    }
    if (event.code == "Space" || event.code == "KeyK") {
        if (document.activeElement != document.querySelector("#startAndStop")) {
            startAndStop();
        }
    }
    if (event.code == "Home") {
        audioElement.currentTime = 0;
    }
    if (event.code == "End") {
        audioElement.currentTime = audioElement.duration;
    }
    if (!isNaN(Number(event.key)) && event.code.indexOf("Digit") == 0) {
        audioElement.currentTime = audioElement.duration * (Number(event.key) / 10);
        seekBarControlByAudio();
    }
});

function volumeIconControl(volume) {
    audioElement.volume = volume;
    const iconElement = document.querySelector("#volume");

    if (volume == 0) {
        iconElement.style.background = "url(./svg/volumeIcons/0.svg)";
    } else if ( volume > (2 / 3) ) {
        iconElement.style.background = "url(./svg/volumeIcons/3.svg)";
    } else if ( volume > (1 / 3) ) {
        iconElement.style.background = "url(./svg/volumeIcons/2.svg)";
    } else if ( volume > 0 ) {
        iconElement.style.background = "url(./svg/volumeIcons/1.svg)";
    }
}
if (Number(localStorage.getItem("isSet")) != 1) {
    localStorage.setItem("volume", 1);
    localStorage.setItem("speed", 1 / 3);
    localStorage.setItem("isSet", 1);
}
volumeIconControl(Number(localStorage.getItem("volume")));

const volumeToolTipElement = document.querySelector("#volumeToolTip");
const volumeBoxElement = document.querySelector("#volumeBox");

volumeBoxElement.addEventListener("mouseover", function() {
    volumeToolTipElement.style.display = "flex";
    volumeBoxElement.style.transform = "translateY(-10rem)";
});
volumeBoxElement.addEventListener("mouseout", function() {
    volumeToolTipElement.style.display = "none";
    volumeBoxElement.style.transform = "translateY(0)";
});

const speedToolTipElement = document.querySelector("#speedToolTip");
const speedBoxElement = document.querySelector("#speedBox");
speedBoxElement.addEventListener("mouseover", function() {
    speedToolTipElement.style.display = "flex";
    speedBoxElement.style.transform = "translateY(-10rem)";
});
speedBoxElement.addEventListener("mouseout", function() {
    speedToolTipElement.style.display = "none";
    speedBoxElement.style.transform = "translateY(0)";
});

function SeekControl(element, negative) {
    const negativeColorCode = "#737f8f";
    const positiveColorCode = "#e3ebed";
    element.style.background = `linear-gradient(90deg, ${negativeColorCode} 0%, ${negativeColorCode} ${negative * 100}%, ${positiveColorCode} ${negative * 100}%, ${positiveColorCode} 100%)`;
}

//Tool Tip
function toolTipControl() {
    document.querySelector("#volumeVal").textContent = Math.round(Number(localStorage.getItem("volume")) * 100) + "%";
    document.querySelector("#speedVal").textContent = Math.round(Number(localStorage.getItem("speed")) * 300) + "%";
}
toolTipControl();
const volumeElement = document.querySelector("#volumeSeek");
volumeElement.value = 100 * Number(localStorage.getItem("volume"));
SeekControl(volumeElement, volumeElement.value / volumeElement.max);
volumeElement.addEventListener("input", function() {
    SeekControl(volumeElement, volumeElement.value / volumeElement.max);
    volumeIconControl(volumeElement.value / volumeElement.max);
    localStorage.setItem("volume", volumeElement.value / volumeElement.max);
    toolTipControl();
});
volumeElement.addEventListener("change", function() {
    let seekBarNegative = volumeElement.value / volumeElement.max;
    localStorage.setItem("volume", seekBarNegative);
    toolTipControl();
});
const speedElement = document.querySelector("#speedSeek");
speedElement.value = 100 * Number(localStorage.getItem("speed"));

SeekControl(speedElement, speedElement.value / speedElement.max);
speedElement.addEventListener("input", function() {
    SeekControl(speedElement, speedElement.value / speedElement.max);
    audioElement.playbackRate = (speedElement.value / speedElement.max) * 3;
    localStorage.setItem("speed", speedElement.value / speedElement.max);
    toolTipControl();
});

audioElement.addEventListener("ended", function() {
    startAndStopElem.classList.add("start");
    startAndStopElem.classList.remove("pause");

    seekBarControlByAudio();
});