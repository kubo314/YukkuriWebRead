/*  jQuery Nice Select - v1.1.0
    https://github.com/hernansartorio/jquery-nice-select
    Made by Hernán Sartorio  */
/*  File with removed jQuery dependency.
    Modification by Kubo
*/
function niceSelect(element) {
    
    element.forEach(function (select) {
        if (select.nextElementSibling == undefined || !select.nextElementSibling.classList.contains("nice-select")) {
            create_nice_select(select);
            select.style.display = "none";
        }
    });

    function create_nice_select(select) {
        let niceSelectElement = document.createElement("div");
        niceSelectElement.classList.add("nice-select")
        if (select.className) {
            niceSelectElement.classList.add(select.className);
        }
        if (select.disabled) {
            niceSelectElement.classList.add("disabled");
        } else {
            niceSelectElement.setAttribute("tabindex", "0");
        }
        niceSelectElement.innerHTML = `<span class="current"></span><ul class="list"></ul>`;

        select.after(niceSelectElement);
        let dropdown = select.nextElementSibling;
        let options = select.querySelectorAll("option");
        let selected = select.querySelectorAll("option")[select.selectedIndex];

        dropdown.querySelector(".current").innerHTML = selected.dataset.display || selected.textContent;

        options.forEach(function (option) {
            let display = option.dataset.display;
            let option_select = document.createElement("li");
            option_select.dataset.value = option.value;
            option_select.dataset.display = display || option.textContent;
            option_select.classList.add("option");
            if (option.selected) {
                option_select.classList.add("selected");
            }
            if (option.disabled) {
                option_select.classList.add("disabled");
            }
            option_select.innerHTML = option.textContent;
            dropdown.querySelector("ul").appendChild(option_select);
        });
    }

    document.querySelector(".nice-select").addEventListener("click", function (event){
        let dropdown = document.querySelector(".nice-select");
        document.querySelectorAll(".nice-select").forEach(function (element) {
            if (element != dropdown) {
                element.classList.remove('open');
            }
        });
        dropdown.classList.toggle("open");

        if (dropdown.classList.contains("open")) {
            dropdown.querySelectorAll(".focus").forEach(function (element) {
                element.classList.remove("focus");
            });
            dropdown.querySelector(".selected").classList.add("focus");
        } else {
            dropdown.focus();
        }
    });
    document.addEventListener("click", function (event){
        let dropdown = document.querySelector(".nice-select");
        if (!event.target.closest(".nice-select")) {
            dropdown.classList.remove("open");
        }
    });
    document.querySelectorAll(".nice-select .option:not(.disabled)").forEach(function (element) {
        element.addEventListener("click", function (){
            let option = this;
            let dropdown = option.closest(".nice-select");

            dropdown.querySelector(".selected").classList.remove("selected");
            option.classList.add("selected");
            
            let text = option.dataset.display || option.textContent;
            dropdown.querySelector(".current").textContent = text;

            dropdown.previousElementSibling.value = option.dataset.value;

            //2023/12/30追加
            //jsからのselectの変更を検知するのが難しいため
            localStorage.setItem("voiceIndex", option.dataset.value)
        });
    });

    document.addEventListener('keydown', function (event) {
        var dropdowns = document.querySelectorAll('.nice-select');
    
        dropdowns.forEach(function (dropdown) {
            var focusedOption = dropdown.querySelector('.focus') || dropdown.querySelector('.list .option.selected');
    
            // Space or Enter
            if (event.keyCode === 32 || event.keyCode === 13) {
                if ([...document.querySelectorAll(".nice-select")].includes(document.activeElement)) {
                    if (dropdown.classList.contains('open')) {
                        focusedOption.click();
                    } else {
                        dropdown.click();
                    }
                    event.preventDefault();
                }
                // Down
            } else if (event.keyCode === 40) {
                if (dropdown.classList.contains('open')) {
                    var nextOption = focusedOption.nextElementSibling;
                    while (nextOption && (!nextOption.classList || nextOption.classList.contains('disabled'))) {
                        nextOption = nextOption.nextElementSibling;
                    }
                    if (!nextOption) {
                        nextOption = dropdown.querySelector('.option:not(.disabled)');
                    }
                    if (nextOption) {
                        focusedOption.classList.remove('focus');
                        nextOption.classList.add('focus');
                    }
                }
                event.preventDefault();
                // Up
            } else if (event.keyCode === 38) {
                if (dropdown.classList.contains('open')) {
                    var prevOption = focusedOption.previousElementSibling;
                    while (prevOption && (!prevOption.classList || prevOption.classList.contains('disabled'))) {
                        prevOption = prevOption.previousElementSibling;
                    }
                    if (!prevOption) {
                        var options = dropdown.querySelectorAll('.option:not(.disabled)');
                        prevOption = options[options.length - 1];
                    }
                    if (prevOption) {
                        focusedOption.classList.remove('focus');
                        prevOption.classList.add('focus');
                    }
                }
                event.preventDefault();
                // Esc
            } else if (event.keyCode === 27) {
                if (dropdown.classList.contains('open')) {
                    dropdown.click();
                }
                // Tab
            } else if (event.keyCode === 9) {
                if (dropdown.classList.contains('open')) {
                    event.preventDefault();
                }
            }
        });
    });
}
window.globalFunction = {};
window.globalFunction.niceSelect = niceSelect;