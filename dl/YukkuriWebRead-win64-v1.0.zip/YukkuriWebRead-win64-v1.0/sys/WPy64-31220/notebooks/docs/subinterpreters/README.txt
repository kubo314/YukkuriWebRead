as of june 10th 2023:

examples made working via syntax reworking from 
https://github.com/ericsnowcurrently/presentations/tree/main/pycon2023