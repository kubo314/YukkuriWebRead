import tinysegmenter
from newspaper import Article
import unicodedata

from html.parser import HTMLParser

#記事を取得してタイトルと100文字で区切った本文を返す(単語を考慮)
def get_and_split_article(html):
    article = Article("")
    segmenter = tinysegmenter.TinySegmenter()

    article.download(input_html = html)
    article.parse()
    text = article.text
    text = unicodedata.normalize("NFKC", text)

    if text == "":
        parser = body_parser()
        parser.feed(html)
        text = parser.body_text
        parser.close()

    words = segmenter.tokenize(text)

    list_of_100_chars = [""]
    for word in words:
        if len(list_of_100_chars[-1]) > 100:
            list_of_100_chars.append("")
        
        list_of_100_chars[-1] += word
    
    return list_of_100_chars


class title_parser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.flag = False
        self.title = ""
    def handle_starttag(self, tag, attrs):
        if tag == "title" and self.title == "":
            self.flag = True
    def handle_data(self, data):
        if self.flag:
            self.title = data
            self.flag = False


class body_parser(HTMLParser):
    def __init__(self, ignore_tags=["rp", "rt"]):
        super().__init__()
        self.in_body = False
        self.ignore_tag = ignore_tags
        self.ignore_mode = False
        self.body_text = ""

    def handle_starttag(self, tag, attrs):
        if tag == "body":
            self.in_body = True
        elif tag in self.ignore_tag:
            self.ignore_mode = True

    def handle_endtag(self, tag):
        if tag == "body":
            self.in_body = False
        elif tag in self.ignore_tag:
            self.ignore_mode = False

    def handle_data(self, data):
        if self.in_body and not self.ignore_mode:
            self.body_text += data