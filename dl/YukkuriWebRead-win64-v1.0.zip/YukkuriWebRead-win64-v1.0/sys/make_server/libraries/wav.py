import wave

def join_wav_files(input_wav_paths, output_wav_path):
    try:
        wav_files = [wave.open(wav_path, "r") for wav_path in input_wav_paths]
        with wave.open(output_wav_path, "w") as output_wav:
            output_wav.setnchannels(wav_files[0].getnchannels())
            output_wav.setsampwidth(wav_files[0].getsampwidth())
            output_wav.setframerate(wav_files[0].getframerate())
            for wav_file in wav_files:
                output_wav.writeframes(wav_file.readframes(wav_file.getnframes()))
                wav_file.close()
        
    except wave.Error as e:
        return e
    except Exception as e:
        return f"wavFile結合時のエラー:{e}"
    else:
        return 0