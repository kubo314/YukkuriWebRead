from ctypes import *
from wrappers.headers.AqKanji2Koe_header import *

def phonetic_transcription(text, instance):
    n_buf_koe = len(text.encode()) * 3 + 50
    koe = create_unicode_buffer(n_buf_koe)
    return_value = AqKanji2Koe_Convert_utf16(instance, text, koe, n_buf_koe)
    if return_value == 0:
        return koe.value
    else:
        return return_value

'''
AquesTalk_Synthe_return_byteの戻り値と内容
(https://www.a-quest.com/archive/manual/aqtk1_win_man.pdf)

戻り値 内容
文字列 正常終了
100   その他のエラー
101   関数呼び出し時の引数が NULL になっている。
104   初期化されていない(初期化ルーチンが呼ばれていない)
105   入力テキストが長すぎる
106   システム辞書データが指定されていない
107   変換できない文字コードが含まれている
200   番台 システム辞書(aqdic.bin)が不正
300   番台 ユーザ辞書(aq_user.dic)が不正
'''