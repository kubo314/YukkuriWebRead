from ctypes import *

AqKanji2Koe_dll = cdll.LoadLibrary("./dlls/AqKanji2Koe/AqKanji2Koe.dll")

#--------------------------------------------------
AqKanji2Koe_SetDevKey = AqKanji2Koe_dll.AqKanji2Koe_SetDevKey
AqKanji2Koe_SetDevKey.restype = c_int
AqKanji2Koe_SetDevKey.argtypes = [c_char_p]
#--------------------------------------------------
AqKanji2Koe_Create = AqKanji2Koe_dll.AqKanji2Koe_Create
AqKanji2Koe_Create.restype = c_void_p
AqKanji2Koe_Create.argtypes = [c_char_p, POINTER(c_int)]
#--------------------------------------------------
AqKanji2Koe_Convert_utf16 = AqKanji2Koe_dll.AqKanji2Koe_Convert_utf16
AqKanji2Koe_Convert_utf16.argtypes = [c_void_p, c_wchar_p, c_wchar_p, c_int]
AqKanji2Koe_Convert_utf16.restype = c_int
#--------------------------------------------------
AqKanji2Koe_Release = AqKanji2Koe_dll.AqKanji2Koe_Release
AqKanji2Koe_Release.restype = c_void_p
AqKanji2Koe_Release.argtypes = None