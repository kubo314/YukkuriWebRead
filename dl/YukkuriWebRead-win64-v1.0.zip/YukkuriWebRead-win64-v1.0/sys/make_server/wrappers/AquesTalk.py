from ctypes import *

def AquesTalk_Synthe_return_byte(voice_index, text, speed):
    voice_types = ["f1", "f2", "m1", "m2", "r1", "imd1", "dvd", "jgr"]
    #--------------------------------------------------
    AquesTalk = cdll.LoadLibrary(f"./dlls/AquesTalk/AquesTalk_{voice_types[voice_index]}.dll")
    #--------------------------------------------------
    AquesTalk_Synthe = AquesTalk.AquesTalk_Synthe
    AquesTalk_Synthe.restype = POINTER(c_ubyte)
    AquesTalk_Synthe.argtypes = [c_char_p, c_int, POINTER(c_int)]
    #--------------------------------------------------
    AquesTalk_FreeWave = AquesTalk.AquesTalk_FreeWave
    AquesTalk_FreeWave.restype = None
    AquesTalk_FreeWave.argtypes = None
    #--------------------------------------------------
    size = c_int()
    wav = AquesTalk_Synthe(text.encode("Shift-JIS"), speed, byref(size))
    
    try:
        if size.value >= 100 and size.value <= 204:
            return size.value
        else:
            return bytes(string_at(wav, size))
    finally:
        AquesTalk_FreeWave(wav)


'''
AquesTalk_Synthe_return_byteの戻り値と内容
(https://www.a-quest.com/archive/manual/aqtk1_win_man.pdf)

戻り値 内容
バイト列 正常終了
100     その他のエラー
101     メモリ不足
102     音声記号列に未定義の読み記号が指定された
103     韻律データの時間長がマイナスなっている
104     内部エラー(未定義の区切りコード検出)
105     音声記号列に未定義の読み記号が指定された
106     音声記号列のタグの指定が正しくない
107     タグの長さが制限を越えている(または[>]がみつからない)
108     タグ内の値の指定が正しくない
109     WAVE 再生ができない(サウンドドライバ関連の問題)
110     WAVE 再生ができない(サウンドドライバ関連の問題 非同期再生)
111     発声すべきデータがない
200     音声記号列が長すぎる
201     １つのフレーズ中の読み記号が多すぎる
202     音声記号列が長い(内部バッファオーバー1)
203     ヒープメモリ不足
204     音声記号列が長い(内部バッファオーバー1)
'''