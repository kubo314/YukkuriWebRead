from wrappers.AqKanji2Koe import *
from wrappers.AquesTalk import *
from libraries.article import *
from libraries.wav import *

import requests
from bs4 import BeautifulSoup

import uuid
import os

from flask import Flask, request, jsonify
from flask_cors import CORS

import subprocess
import ast

#-----------------------------------------------------------------
def make_voice(URL, VOICE_INDEX, key):
    SPEED = 100
    AqKanji2Koe_key = key.encode()
    #-----------------------------------------------------------------
    #AqKanji2Koe制限解除
    if AqKanji2Koe_SetDevKey(AqKanji2Koe_key) == 1:
        return "AqKanji2Koeの制限を解除できませんでした。"
        exit()
    #-----------------------------------------------------------------
    #AqKanji2Koeインスタンス生成
    p_err = c_int(0)
    instance = AqKanji2Koe_Create(b"./aq_dic", byref(p_err))
    if p_err.value != 0:
        return f"AqKanji2Koeのインスタンス生成に失敗しました。 ErrorCode:{p_err.value}"
        exit()
    #-----------------------------------------------------------------
    #html取得
    response = requests.get(URL)
    soup = BeautifulSoup(response.content, "html.parser")
    html = str(soup)
    #-----------------------------------------------------------------
    #タイトル取得
    title = soup.title.text
    #-----------------------------------------------------------------
    #本文取得&100文字区切り

    chunks = get_and_split_article(html)
    if len(chunks) <= 1 and chunks[0] == "":
        return "ページ取得に失敗しました。"
        exit()
    #-----------------------------------------------------------------
    #wavファイル先頭のuuid生成
    uuid_str = str(uuid.uuid1())
    #-----------------------------------------------------------------
    #音声記号列生成&音声合成
    wav_files = []
    i = 0
    for chunk in chunks:
        #音声記号列生成
        phonetic_text = phonetic_transcription(chunk, instance)
        if type(phonetic_text) is not str:
            return f"音声記号列生成に失敗しました。 ErrorCode: {phonetic_text}"
            break
        #つなぎに違和感が生じないように最後の"。"は削除
        if phonetic_text[-1] == "。":
            phonetic_text = phonetic_text[:-1]
        
        #音声合成&保存
        voice_byte = AquesTalk_Synthe_return_byte(VOICE_INDEX, phonetic_text, SPEED)
        if type(voice_byte) is not bytes:
            return f"音声合成に失敗しました。 ErrorCode: {voice_byte}"
            break
        
        with open(f"./wav_temp/{uuid_str}_{i}.wav", "wb") as f:
            f.write(voice_byte)
        
        wav_files.append(f"./wav_temp/{uuid_str}_{i}.wav")
        i += 1
    #-----------------------------------------------------------------
    #wav fileを結合
    file_count = len(os.listdir("../output_wav"))
    output_wav_path = f"../output_wav/{file_count}.wav"
    join_wav_result = join_wav_files(wav_files, output_wav_path)
    #-----------------------------------------------------------------
    #wav_tamp内のファイルを全て削除
    temp_wav_file_name_list = os.listdir("./wav_temp")
    for file_name in temp_wav_file_name_list:
        os.remove(f"./wav_temp/{file_name}")
    #-----------------------------------------------------------------
    if join_wav_result == 0:
        #return [os.path.abspath(output_wav_path).replace("\\", "/"), title]
        return [f"./output_wav/{file_count}.wav", title]
    else:
        return join_wav_result

app = Flask(__name__)
CORS(app)
@app.route("/")
def return_voice():
    parameters = request.args
    if "voice_index" in parameters and "url" in parameters:
        subprocess.run(["./open.exe", parameters["url"], str(parameters["voice_index"])], creationflags=subprocess.DETACHED_PROCESS)
        with open("./return.txt", "r") as f:
            return_text = f.read()
            return_list = return_text.split("\n")
            
            return jsonify({"datas": return_list})
    else:
        return "パラーメーターが不正です。"

if __name__ == '__main__':
    app.run()