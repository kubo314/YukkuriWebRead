import subprocess
import os
import tkinter as tk
import pathlib
import shutil

def start():
    import webview
    def on_closed():
        proc.kill()
    proc = subprocess.Popen(["pythonw", "./make.py"], cwd="./make_server")
    window = webview.create_window("Yukkuri Web Read", url="./index.html")
    window.events.closed += on_closed
    webview.start(http_server=False, private_mode=False, http_port=5019)

if os.path.isfile("IS_SET_AGREEMENT.txt"):
    start()
else:
    with open("./agreement/agreement.txt", "r", encoding="utf-8") as f:
        agreement_text = f.read()

    def button_click():
        root.destroy()
        is_set_ag_file = pathlib.Path("./IS_SET_AGREEMENT.txt")
        is_set_ag_file.touch()

    root = tk.Tk()
    root.iconbitmap(default="./icon/icon.ico")
    root.title("Yukkuri Web Read 利用規約")

    text_widget = tk.Text(root)
    text_widget.insert(1.0, agreement_text)
    text_widget.configure(state="disabled")
    text_widget.pack()

    button = tk.Button(root, text="同意", command=button_click)
    button.pack()

    root.mainloop()

if not os.path.isfile("IS_SET.txt"):
    if os.path.isfile("IS_SET_AGREEMENT.txt"):
        print(os.getcwd())
        dialog_proc = subprocess.Popen(["pythonw","./dialog.py"], cwd="./dialog")
        subprocess.run("python -m pip install -r requirements.txt")
        shutil.copy("./change_file/winforms.py", "./WPy64-31220/python-3.12.2.amd64/Lib/site-packages/webview/platforms/winforms.py")
        dialog_proc.kill()
        is_set_ag_file = pathlib.Path("./IS_SET.txt")
        is_set_ag_file.touch()

        start()