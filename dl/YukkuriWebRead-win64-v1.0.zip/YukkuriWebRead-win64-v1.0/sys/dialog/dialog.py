import tkinter as tk

root = tk.Tk()
root.geometry("300x100")
root.title("Yukkuri Web Read インストール状況")
root.iconbitmap(default="../icon/icon.ico")
tk.Label(root, text="モジュールインストール中です。\nしばらくお待ちください。", font=("MSゴシック", "10", "bold")).pack(anchor='center',expand=1)

root.mainloop()